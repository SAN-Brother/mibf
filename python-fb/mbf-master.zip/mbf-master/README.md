# mbf
use python versi 3

$ pkg update && pkg upgrade

$ pkg install python

$ pip install requests

$ pkg install git

$ git clone https://github.com/unikers71/mbf

$ cd mbf

$ python3 mbf.py
